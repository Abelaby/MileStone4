package com.kral.productmanagement.product.model;

import jakarta.persistence.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data

public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(nullable = false)
	private ProductType productType; 

}
