package com.kral.productmanagement.product.service;

import java.util.List;

import com.kral.productmanagement.product.model.Product;
import com.kral.productmanagement.product.model.ProductType;
import com.kral.productmanagement.product.vo.ProductVO;

public interface ProductService {
	Product productById(Integer productId);
	List<Product> productsByType(ProductType productType);
	Product postProduct(Product product);
	ProductVO getProductAndDescriptionById(Integer productId);
}
