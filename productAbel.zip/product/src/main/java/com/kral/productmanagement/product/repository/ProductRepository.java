package com.kral.productmanagement.product.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kral.productmanagement.product.model.Product;
import com.kral.productmanagement.product.model.ProductType;

@Repository
public interface ProductRepository extends JpaRepository<Product,Integer> {
	List<Product> findByProductType(ProductType productType);

}
