package com.kral.productmanagement.product.vo;

public class DescriptionVO {
	private Integer id;
	private String brand;
	private String model;
	private Integer price;
}
