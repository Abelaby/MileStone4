package com.kral.productmanagement.product.model;

public enum ProductType {
	Mobile, Laptop

}
