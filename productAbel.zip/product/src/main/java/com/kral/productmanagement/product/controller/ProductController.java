package com.kral.productmanagement.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kral.productmanagement.product.model.Product;
import com.kral.productmanagement.product.model.ProductType;
import com.kral.productmanagement.product.service.ProductService;
import com.kral.productmanagement.product.service.ProductServiceImpl;
import com.kral.productmanagement.product.vo.ProductVO;

@RestController
@RequestMapping("product")
public class ProductController {
	
	@Autowired
	private ProductServiceImpl productService;
	
	@PostMapping("/addproduct")
	public Product newProduct(@RequestBody Product product) {
		return productService.postProduct(product);
	}
	
	@GetMapping("/byid/{id}")
	public Product getById(@PathVariable Integer id) {
		return productService.productById(id);
	}
	
	@GetMapping("/bytype/{type}")
	public List<Product> getByType(@PathVariable ProductType type){
		return productService.productsByType(type);
	}
	
	@GetMapping("/productwithdescription/{id}")
	public ProductVO getProductWithDescription(@PathVariable Integer id) {
		return productService.getProductAndDescriptionById(id);
	}
}
